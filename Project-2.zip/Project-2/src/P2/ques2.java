package P2;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class ques2 {
	public static class MapTemp extends Mapper<LongWritable, Text, Text, Text>
	{
		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
			
			String line =value.toString();
			String[] st= line.split("\\s+");//splitting the data on the basis of space, \\s+ adjusts the space according to data and splits the data
			String s =st[1];
			float max=Float.parseFloat(st[5]); //storing index number in float
			float min=Float.parseFloat(st[6]); //storing index number in float
			
			
			//condition for hot and cold day
			
			if(min<10){
				con.write(new Text("Cold Day   "+s), new Text(String.valueOf(min))); //writing the output that will be sent to reducer 
			}
			if (max>35){
				con.write(new Text("Hot Day    "+s), new Text(String.valueOf(max))); //writing the output that will be sent to reducer 
			}
		}
	}
	
	public static class ReduceTemp extends Reducer<Text, Text, Text, Text>{
		public void reduce (Text lines, Iterator<Text> values, Context con)throws IOException, InterruptedException{
			
			// the cold days or hot days are collected using sum
			String output=values.next().toString();
			
		con.write(lines, new Text(output));
		}
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		Configuration conf= new Configuration();
		Job j=Job.getInstance(conf,"highestTemp");
		j.setJarByClass(ques2.class);
		j.setMapperClass(MapTemp.class);
		j.setReducerClass(ReduceTemp.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(Text.class); //output in FloatWritable
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
	}
}
