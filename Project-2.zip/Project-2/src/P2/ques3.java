package P2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class ques3 {
	public static class Maphightemp extends Mapper<LongWritable, Text, DoubleWritable, Text>{

		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{

		String line = value.toString();
		String[] st=line.split("\\s+");
		String date =st[1];
		String High = st[5];
		String Low = st[6];

		double max = Double.parseDouble(High);
		double min = Double.parseDouble(Low);

		con.write(new DoubleWritable(min), new Text(date));
		con.write(new DoubleWritable(max), new Text(date));
		}
		}
		public static class ReduceForhtemp extends Reducer< DoubleWritable, Text, DoubleWritable,Text>{
			
		TreeMap<DoubleWritable, Text> low = new TreeMap<DoubleWritable, Text>();
		TreeMap<DoubleWritable, Text> high = new TreeMap<DoubleWritable, Text>();
		
		int i = 0;
		public void reduce(DoubleWritable key, Iterable<Text> values, Context con) throws IOException, InterruptedException{

		double temp = key.get();
		String date = values.iterator().next().toString();


		if (i < 10) {
		low.put(new DoubleWritable(temp), new Text(date));
		++i;
		}


		low.put(new DoubleWritable(temp), new Text(date));
		if (low.size() > 10) {

		low.remove(low.keySet().iterator().next());
		}
		}

		public void cleanup(Context con) throws IOException, InterruptedException {

		con.write(null, new Text("Top 10 Coldest Days: "));
		for (Entry<DoubleWritable, Text> t : low.entrySet()) {
		con.write(t.getKey(), t.getValue());
		}

		con.write(null, new Text("Top 10 Hottest Days: "));
		List<DoubleWritable> hkey = new ArrayList<DoubleWritable>(
		low.keySet());
		Collections.reverse(hkey);

		for (int i = 0; i < hkey.size(); i++) {
		con.write(hkey.get(i), low.get(hkey.get(i)));
		}
		}

		}
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		Configuration conf= new Configuration();
		Job j=Job.getInstance(conf,"Hot and Cold");
		j.setJarByClass(ques3.class);
		j.setMapperClass(Maphightemp.class);
		j.setReducerClass(ReduceForhtemp.class);
		j.setOutputKeyClass(DoubleWritable.class);
		j.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
		}
}
