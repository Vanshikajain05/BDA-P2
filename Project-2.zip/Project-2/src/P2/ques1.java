package P2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class ques1 {
	public static class MapHighest extends Mapper<LongWritable, Text, Text, FloatWritable>
	{
		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
			
			String line =value.toString();  //storing text in string
			String[] st= line.split("\\s+");   //splitting the data on the basis of space, \\s+ adjusts the space according to data and splits the data
			
			String s=st[1];
				Text year= new Text((s.substring(0,4))); //substring is used to read data from 0 up to 4 index which means 4th will e exclusive (not included)
				
				float temp= Float.parseFloat(st[5]);     //storing string in float
				FloatWritable f=new FloatWritable(temp);  
				con.write(year,f);  //writing the output that will be sent to reducer 
			
		}
	}
	
	public static class ReduceHighest extends Reducer<Text, FloatWritable, Text, FloatWritable>{
		public void reduce (Text lines, Iterable<FloatWritable> values, Context con)throws IOException, InterruptedException{
			float max=(float) 0.0;
			
			//for loop to find the max temperature
			for(FloatWritable write:values){ 
				float f=write.get();
				if(f>max){
					max=f; //setting the value of in max and loop starts again
				}
			}
			con.write(lines, new FloatWritable(max)); //writing the final values as output
		}
		}
		
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		Configuration conf= new Configuration();
		Job j=Job.getInstance(conf,"highestTemp");
		j.setJarByClass(ques1.class);
		j.setMapperClass(MapHighest.class);
		j.setReducerClass(ReduceHighest.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(FloatWritable.class);  //output in FloatWritable
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
	}
}
